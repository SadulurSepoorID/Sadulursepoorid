// Animasi tambahan jika diperlukan
document.addEventListener("DOMContentLoaded", () => {
    console.log("Halaman dimuat dengan animasi.");
});